<?php
session_start(); // Start the session at the beginning of your script


if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
        <title>Stock Edit</title>
        <link rel="stylesheet" type="text/css" href="Stock_Edit.css">
        <link rel="icon" type="image/x-icon" href="icon.png">

</head>
<?php
$ProductId = $_POST["ProductId"];
$ProductName = $_POST["product_name"];
$Price = $_POST["price"];
$Quantity = $_POST["quantity"];
$Expiry_Date = $_POST["ExpiryDate"];
$DateEnterStore = $_POST["Date_Enter_Store"];
$Type = $_POST["type"];
$Description = $_POST["desc"];

?>
<center>
<body>
    <div class= "center-container">
        <div class="container">
        <h2>Update Stock Details</h2>
    
    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "STORE_MANAGEMENT_SYSTEM";

    $conn = new mysqli($host, $user, $pass, $db);
    if ($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }
    else
    {
        $queryUpdate = "UPDATE STOCK SET Product_Name = '".$ProductName."', Price = '".$Price."', Quantity = '".$Quantity."', Expiry_Date = '".$Expiry_Date."', Date_In_Store = '".$DateEnterStore."', Type = '".$Type."', Description = '".$Description."' WHERE Prodcut_ID = '".$ProductId."'";
        If ($conn->query($queryUpdate) === TRUE){
            echo "<p style='color:green;'> Record has been updated into database !</p>";
            echo "<button onclick=\"location.href='Dashboard.php'\">Go to Homepage</button>";

        } else {
            echo "<p style='color=red;'>Query problems! : " . $conn->error . "</p>";
        }
        
    }
    $conn->close();
    ?>
        </div>
    </div>

</body>
</center>
</html>
