<?php
session_start(); // Start the session at the beginning of your script

$_SESSION['login_date'] = date('Y-m-d');

if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Picture Upload</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            color: #333;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            margin: 10px 0;
        }

        input[type="file"] {
            margin-bottom: 20px;
        }

        button {
            padding: 10px 20px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        p {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .error {
            color: red;
            text-align: center;
        }

        .success {
            color: green;
            text-align: center;
        }
    </style>
</head>

<body>
    <?php
    // Your existing PHP code here
    ?>

    <div class="container">

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["profile_pic"])) {
            $StaffID = $_SESSION["Staff_ID"];
        
            $host = "localhost";
            $user = "root";
            $pass = "";
            $db = "STORE_MANAGEMENT_SYSTEM";
        
            $conn = new mysqli($host, $user, $pass, $db);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
        
            // Check if a file is uploaded
            if ($_FILES["profile_pic"]["error"] == 0) {
                // If a file is uploaded, process the file
        
                // Check if the file is an image
                $allowedTypes = ["image/jpeg", "image/jpg", "image/png"];
                if (!in_array($_FILES["profile_pic"]["type"], $allowedTypes)) {
                    echo "<p style='color:red;'>Invalid file type. Only JPEG, JPG, and PNG images are allowed.</p>";
                    exit;
                }
        
                $targetDirectory = "profile_pics/";
                $targetFile = $targetDirectory . basename($_FILES["profile_pic"]["name"]);
        
                if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $targetFile)) {
                    // Update the file name in the database
                    $queryUpdate = "UPDATE USER SET Profile_Pic = '" . $targetFile . "' WHERE Staff_ID = '" . $StaffID . "'";
        
                    if ($conn->query($queryUpdate) === TRUE) {
                        echo "<p style='color:green;'>Profile picture has been updated into the database!</p>";
                        echo "<p style='color:#84A4FC;'>Click <a style='color:green;' href='Profile_View.php'>here</a> to view your profile</p>";
                    } else {
                        echo "<p style='color:red;'>Query problems! : " . $conn->error . "</p>";
                    }
                } else {
                    echo "Sorry, there was an error uploading your profile picture.";
                }
            } else {
                // If no file is uploaded, update the database without changing the profile picture
                $queryUpdate = "UPDATE USER SET Profile_Pic = Profile_Pic WHERE Staff_ID = '" . $StaffID . "'";
        
                if ($conn->query($queryUpdate) === TRUE) {
                    echo "<p style='color:green;'>Profile information has been updated into the database!</p>";
                    echo "<p style='color:#84A4FC;'>Click <a style='color:green;' href='Profile_View.php'>here</a> to view your profile</p>";
                } else {
                    echo "<p style='color:red;'>Query problems! : " . $conn->error . "</p>";
                }
            }
        
            $conn->close();
        } else {
            // Display an error message if the form is not submitted properly
            echo "Invalid request!";
        }
        ?>
    </div>
</body>

</html>



