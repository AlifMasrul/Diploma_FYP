<?php
session_start(); // Start the session at the beginning of your script


if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Update Profile</title>
    <link rel="icon" type="image/x-icon" href="icon.png">
</head>

<body>
    <br><br>
    <center>
        <h2 style="color: #84A4FC">Update Profile Data</h2>

        <?php
        $host = "localhost";
        $user = "root";
        $pass = "";
        $db = "STORE_MANAGEMENT_SYSTEM";

        $conn = new mysqli($host, $user, $pass, $db);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } else {
            $StaffID = $_SESSION["Staff_ID"];
            $Name = $_POST["StaffName"];
            $Dob = $_POST["umur"];
            $Nickname = $_POST["nickname"];

            // Check if a file is uploaded
            if ($_FILES["profile_pic"]["error"] == 0) {
                $targetDirectory = "profile_pics/";
                $targetFile = $targetDirectory . basename($_FILES["profile_pic"]["name"]);

                if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $targetFile)) {
                    // Update the file name in the database
                    $queryUpdate = "UPDATE USER SET Staff_ID = '" . $StaffID . "', Name = '" . $Name . "', Dob = '" . $Dob . "', NickName = '" . $Nickname . "', Profile_Pic = '" . $targetFile . "' WHERE Staff_ID = '" . $StaffID . "' ";

                    if ($conn->query($queryUpdate) === TRUE) {
                        echo "<p style='color:green;'> Record has been updated into the database!</p>";
                        echo "<p style='color:#84A4FC;'> Click <a style='color:green;' href='Profile_View.php'> here </a> to view your profile </p>";
                    } else {
                        echo "<p style='color=red;'>Query problems! : " . $conn->error . "</p>";
                    }
                } else {
                    echo "Sorry, there was an error uploading your profile picture.";
                }
            } else {
                // Update without changing the profile picture
                $queryUpdate = "UPDATE USER SET Staff_ID = '" . $StaffID . "', Name = '" . $Name . "', Dob = '" . $Dob . "', NickName = '" . $Nickname . "' WHERE Staff_ID = '" . $StaffID . "' ";

                if ($conn->query($queryUpdate) === TRUE) {
                    echo "<p style='color:green;'> Record has been updated into the database!</p>";
                    echo "<p style='color:#84A4FC;'> Click <a style='color:green;' href='Profile_View.php'> here </a> to view your profile </p>";
                } else {
                    echo "<p style='color=red;'>Query problems! : " . $conn->error . "</p>";
                }
            }
        }

        $conn->close();
        ?>
    </center>
</body>

</html>