<?php
session_start(); // Start the session at the beginning of your script


if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Profile Edit</title>
    <link rel="stylesheet" href="Profile_Edit.css">
    <link rel="icon" type="image/x-icon" href="icon.png">
</head>

<?php
$ProductId = $_REQUEST["ProductID"];
$host = "localhost";
$user = "root";
$pass = "";
$db = "STORE_MANAGEMENT_SYSTEM";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    $queryGet = "SELECT * FROM STOCK WHERE Prodcut_ID = '" . $ProductId . "' ";
    $resultGet = $conn->query($queryGet);

    if ($resultGet->num_rows > 0) {
        while ($row = $resultGet->fetch_assoc()) {
?>

            <body>
                <center>
                    <h2> Edit Your Profile </h2>
                    <h4>All <span style="color: red;">*</span> are required</h4>

                    <form name="EditProfile" action="Stock_Image_Edit_Reg.php" method="POST" enctype="multipart/form-data">
                        <b>Product ID: <?php echo $row["Prodcut_ID"]; ?></b>
                        <br><br>
                        <?php
                        // Check if the profile picture path is set in the database
                        if (!empty($row["Stock_Pic"])) {
                        ?>
                            <img src="<?php echo $row["Stock_Pic"]; ?>" style="max-width: 100px; max-height: 100px;" width="100" height="100">
                        <?php
                        }
                        ?>
                        <br><br>
                        Stock Picture : <input type="file" name="stock_pic" accept=".jpg, .jpeg, .png">
                        <br><br>
                        <input type="hidden" name="Product_ID" value="<?php echo $row["Prodcut_ID"]; ?>" required>
                        <input type="submit" value="Submit">
                        <input type="reset" value="Re-enter">
                    </form>
                </center>
            </body>

</html>

<?php
        }
    } else {
        echo "<p colspan='8' style='color:red'; >No data selected</p>";
    }
}

$conn->close();
?>