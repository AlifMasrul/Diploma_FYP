<?php
session_start(); // Start the session at the beginning of your script


if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Profile Edit</title>
    <link rel="stylesheet" href="Profile_Edit.css">
    <link rel="icon" type="image/x-icon" href="icon.png">
</head>

<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "STORE_MANAGEMENT_SYSTEM";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    $queryGet = "SELECT * FROM USER WHERE Staff_ID = '".$_SESSION["Staff_ID"]."' ";
    $resultGet = $conn->query($queryGet);

    if ($resultGet->num_rows > 0) {
        while ($row = $resultGet->fetch_assoc()) {
            ?>
            <body style="background-color: #bcbcbc;">
                <center>
                    <h2> Edit Your Profile </h2>
                    <h4>All <span style="color: red;">*</span> are required</h4>

                    <form name="EditProfile" action="ProfileReg.php" method="POST" enctype="multipart/form-data">
                    <b> Staff ID: <?php echo $row["Staff_ID"] ?></b>
                        <br><br>
                        <img src="<?php echo $row["Profile_Pic"]; ?>" alt="Profile Picture" class="profile-pic" style="max-width: 100px; max-height: 100px;">
                        <br><br>
                        <td>Click<a href="Profile_Image_Edit.php?StaffID=<?php echo $row["Staff_ID"]; ?>" class="available-btn"> here </a>to edit profile picture</td>
                        <br><br>
                        Name : <span style="color: red;">* </span>
                        <input type="text" name="StaffName" size="60" value="<?php echo $row["Name"]; ?>" maxlength="55" required autofocus>
                        <br><br>

                        Date of Birth : <span style="color: red;">* </span>
                        <input type="date" name="umur" max="2005-01-01" value="<?php echo $row["Dob"]; ?>">
                        <br><br>

                        NickName : <input type="text" name="nickname" size="20" value="<?php echo $row["NickName"]; ?>" maxlength="15">
                        <br><br>

                        <input type="hidden" name="StaffId" value="<?php echo $row["Staff_ID"]; ?>" required>
                        <input type="submit" value="Submit">
                        <input type="reset" value="Re-enter">
                    </form>
                </center>
            </body>
            </html>

            <?php 
        }
    } else {
        echo "<p colspan='8' style='color:red'; >No data selected</p>";
    }
}

$conn->close();
?>
