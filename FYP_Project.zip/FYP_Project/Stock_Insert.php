<?php
session_start(); // Start the session at the beginning of your script

$_SESSION['login_date'] = date('Y-m-d');

if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Add Stock</title>
    <link rel="stylesheet" href="Stock_Insert.css">
    <link rel="icon" type="image/x-icon" href="icon.png">
</head>

<body style="background-color: #bcbcbc;">

    <div>
        <br>
        <h1> Add Stock </h1>
        <form name="stockForm" action="Stock_Insert_Reg.php" method="POST" enctype="multipart/form-data">
            Product Name : <input type="text" name="product_name" size="35" maxlength="30" autofocus required>
            <br><br>
            Price : <input type="number" name="price" min="1" step="0.01" required>
            <br><br>
            Quantity : <input type="number" name="quantity" min="5" step="1" size="30" required>
            <br><br>
            Expiry date: <input type="date" name="expiry_date" min="<?php echo $_SESSION['login_date'] ?>" required>
            <br><br>
            Date that entered store : <input type="date" name="date_in_store" required>
            <br><br>
            Type :
            <select name="item_type">
                <option value="Sayur">Sayur</option>
                <option value="Minuman">Minuman</option>
                <option value="Barangan Kering">Barangan Kering</option>
                <option value="Tenusu">Produk Tenusu</option>
                <option value="isi rumah">Barangan isi rumah</option>
                <option value="Makanan Ringan">Makanan Ringan</option>
                <!-- Add more options as needed -->
            </select>
            <br><br>
            Description : <input type="text" name="desc" size="40">
            <br><br>
            Stock Picture : <input type="file" name="stock_pic">
            <br><br>

            <input type="submit" value="Submit">
            <input type="reset" value="Reset">
        </form>
    </div>

</body>

</html>