<?php
session_start(); // Start the session at the beginning of your script


if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <Title>Profile</Title>
	<link rel="stylesheet" href="Profile_Views.css">
</head>
<body>
    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "STORE_MANAGEMENT_SYSTEM";

    $connection = new mysqli($host, $user, $pass, $db);

    if ($connection->connect_error)
    {
        die("Connection failed: " . $connection->connect_error);
    }

    else
    {
        $queryview = "SELECT * From USER WHERE Staff_ID = '".$_SESSION["Staff_ID"]."'";
        $resultQ = $connection->query($queryview);
        ?>

        <?php
            if ($resultQ->num_rows > 0)
            {
                while($row = $resultQ->fetch_assoc())
                {
        ?>
		
        <div class="container">
        <center>
            <h2> Your Profile </h2>
            <br><br>
            <div class="profile-info">
                    <?php
                    // Check if the profile picture path is set in the database
                    if (!empty($row["Profile_Pic"])) {
                        ?>
                        <img src="<?php echo $row["Profile_Pic"]; ?>" alt="Profile Picture" class="profile-pic" style="max-width: 100px; max-height: 100px;">
                        <?php
                    }
                    ?>
                    <p> <b>Staff ID : </b><?php echo $row["Staff_ID"]; ?> </p>
                    <p> <b>Name : </b><?php echo $row["Name"]; ?> </p>
                    <p> <b>Nickname : </b><?php echo $row["NickName"]; ?> </p>
                    <p> <b>Date Of Birth : </b><?php echo $row["Dob"]; ?> </p>
                    <a class="button edit-link" href="Profile_Edit.php">Edit Your Profile</a>
                    <a class="button home-link" href="Dashboard.php">Go to Homepage</a>
                </div>
        </center>
		</div>

        <?php 
                }
            }
            else
            {
                echo "<center>";
                echo "<h2> Your Profile </h2>";

                echo "You don't have any profile yet";
                echo "<br><br>";
                echo "<a href='Profile_EditForm.php'>Click here to Register your profile</a>";
                echo "</center>";

            }
    }
    $connection->close();
    ?>

</body>
</html>