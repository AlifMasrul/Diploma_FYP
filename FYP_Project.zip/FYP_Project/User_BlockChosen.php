<?php
session_start();

if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Block Page</title>
    <link rel="icon" type="image/x-icon" href="icon.png">
    <style>
        body {
            background-color: #bcbcbc;
            font-family: Arial, sans-serif;
            text-align: center;
        }
        .container {
            margin-top: 100px;
            padding: 20px;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin-left: auto;
            margin-right: auto;
        }
        .message {
            color: red;
            font-size: 25px;
            margin-bottom: 20px;
        }
        .link {
            color: blue;
            font-size: 15px;
            text-decoration: none;
        }
        .link:hover {
            color: green;
        }
    </style>
</head>
<body>

<div class="container">
    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "STORE_MANAGEMENT_SYSTEM";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {
        $StaffID = $_REQUEST["StaffID"];
        $queryUpdate = "UPDATE USER SET Status = 'Block' WHERE Staff_ID = '".$StaffID."'";

        if ($conn->query($queryUpdate) === TRUE) {
            echo "<p class='message'>Staff has been blocked!</p>";
            echo "<p>Click <a class='link' href='Dashboard.php'>here</a> to go to Homepage</p>";
        } else {
            echo "<p style='color:red;'>Query problems! : " . $conn->error . "</p>";
        }
    }
    $conn->close();
    ?>
</div>

</body>
</html>
