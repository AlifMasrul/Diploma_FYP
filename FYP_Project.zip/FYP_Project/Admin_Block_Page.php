<?php
session_start(); // Start the session at the beginning of your script


if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title> Block Page </title>
	<link rel="stylesheet" href="CSSAdminBlockPage.css">
    <link rel="icon" type="image/x-icon" href="icon.png">
</head>
<center>
<body>

    <h2> Store Staff</h2>
    <?php 
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "STORE_MANAGEMENT_SYSTEM";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn ->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    else
    {
        $queryview = "SELECT * From USER" ;
        $resultQ = $conn->query($queryview);
    ?>
    <table border="2">
        <tr>
            <th> Staff ID </th>
            <th> Name </th>
            <th> Date Of Birth </th>
            <th> Nickname </th>
            <th> Status </th>
            <th> Activate </th>
            <th> Block </th>
    </tr>

    <?php 
        if ($resultQ->num_rows > 0)
        {
            while($row =$resultQ->fetch_assoc()) 
            {
    ?>
    <tr> 
        <td> <?php echo $row["Staff_ID"]; ?> </td>
        <td> <?php echo $row["Name"]; ?> </td>
        <td> <?php echo $row["Dob"]; ?> </td>
        <td> <?php echo $row["NickName"]; ?> </td>
        <td> <?php echo $row["Status"]; ?> </td>
        <td><a href="User_ActivateChosen.php?StaffID=<?php echo $row["Staff_ID"]; ?>" onclick="return confirm('Are you sure to block this user?')">Activate</a></td>
        <td><a href="User_BlockChosen.php?StaffID=<?php echo $row["Staff_ID"]; ?>" onclick="return confirm('Are you sure to block this user?')">Block</a></td>
    </tr>
    <?php
            }
        } 
        else 
        { 
            echo "<tr><td colspan='8'> NO data selected </td></tr>";
        }

    }
    ?>

</table>
<?php
$conn->close();
?>
<br>

</form>
</body>
</center>
</html>