<?php
session_start(); // Start the session at the beginning of your script

$_SESSION['login_date'] = date('Y-m-d');

if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title> Store Management System </title>
    <link rel="icon" type="image/x-icon" href="icon.png">
    <link rel="stylesheet" href="Image_Edit.css">
</head>

<body>

<div class="container">
    <?php
    $ProductID = $_POST["Product_ID"];
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "STORE_MANAGEMENT_SYSTEM";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Connection failed" . $conn->connect_error);
    } else {

        // File upload handling
        $targetDirectory = "stock_pics/"; // Specify the directory where you want to store the uploaded profile pictures
        $targetFile = $targetDirectory . basename($_FILES["stock_pic"]["name"]);

        // Check if the file is an image
        $allowedTypes = ["image/jpeg", "image/jpg", "image/png"];
        if (!in_array($_FILES["stock_pic"]["type"], $allowedTypes)) {
            echo "<p style='color:red; text-align:center;'>Invalid file type. Only JPEG, JPG, and PNG images are allowed.</p>";
            echo "<p style= 'text-align: center;'>Click <a href='Stock_Edit_Details.php?ProductID=$ProductID'>here</a> to edit back</p>";
            exit;
        }

        if (move_uploaded_file($_FILES["stock_pic"]["tmp_name"], $targetFile)) {
            // Update the database insertion query to include the file information
            $queryUpdate = "UPDATE STOCK SET Stock_Pic = '" . $targetFile . "' WHERE Prodcut_ID = '" . $ProductID . "'";

            if ($conn->query($queryUpdate) === TRUE) {
                echo "<center><p style='color:green;'>You have successfully updated the Stock Picture</p></center>";
            } else {
                echo "<p style='color:red;'>Connection error " . $conn->error . "</p>";
            }
        } else {
            // Error uploading file
            echo "<p style='color:red;'>Sorry, there was an error uploading your stock picture.</p>";
        }
    }
    $conn->close();
    ?>
    </div>

</body>

</html>
