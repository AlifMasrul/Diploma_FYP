<?php
session_start(); // Start the session at the beginning of your script


if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
        <?php 
        $StaffID = $_REQUEST["StaffID"];
        ?>
        <title> Activate Page </title>
        <link rel="icon" type="image/x-icon" href="icon.png">
</head>
<center>
<body>
<br><br>
        <h2 style= "color: #84A4FC"> Blocked User Data </h2>

        <?php

        $host = "localhost";
        $user = "root";
        $pass = "";
        $db = "STORE_MANAGEMENT_SYSTEM";

        $conn = new mysqli($host, $user, $pass, $db);

        if ($conn->connect_error)
        {
            die("Connection failed: " . $conn->connect_error);
        }
        else
        {
            $queryUpdate = "UPDATE USER SET Status = 'Active' WHERE Staff_ID = '".$StaffID."'";

            if ($conn->query($queryUpdate) === TRUE)
            {
                echo "<p style='color:green;'>  Record has been updated from database !</p>";
                echo "<p style='color:#84A4FC;'> Click <a style='color:green;' href='Dashboard.php'> here </a> to go to Homepage </p>";
            } 
            else 
            {
                echo "<p style='color:red;'>Query problems! : " . $conn->error . "</p>";
            }
        }
        $conn->close();
        ?>

</body>
</center>
</html>