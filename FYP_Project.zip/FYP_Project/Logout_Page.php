<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <link rel="icon" type="image/x-icon" href="icon.png">
    <link rel="stylesheet" type="text/css" href="Logout_Page.css">
</head>
<body>
    <?php 
    session_start(); 
    if (isset($_SESSION["Staff_ID"])) { 
        session_unset(); 
        session_destroy(); 

        echo "<div class='container'>";
        echo "<p class='success'>You have successfully logged out.</p>"; 
        echo "<p>Click <a href='Login_Page.html'>here</a> to LOGIN again.</p>"; 
        echo "</div>";

    } else { 
        echo "<div class='container'>";
        echo "<p class='error'>No session exists or session is expired. Please log in again.</p>"; 
        echo "<p>Click <a href='Login_Page.html'>here</a> to LOGIN again.</p>";  
        echo "</div>";
    } 
    ?>
</body>
</html>
