<?php
// Start the session at the beginning of your script
session_start();

// Check if the user is logged in
if (!isset($_SESSION['Staff_ID'])) {
    // User is not logged in, redirect to login page
    header("Location: Login_Page.html");
    exit;
}

// Check for session expiration based on your desired timeout (e.g., 30 minutes)
$sessionTimeout = 30 * 60; // 30 minutes

if (isset($_SESSION['last_login_time']) && (time() - $_SESSION['last_login_time'] > $sessionTimeout)) {
    // Session has expired
    session_unset();
    session_destroy();
    header("Location: Login_Page.html");
    exit;
}

// Update last login time
$_SESSION['last_login_time'] = time();

// User is logged in
if ($_SESSION['User_Type'] == 'Admin') {
    include 'Admin_Navbar.php'; // Include admin navbar
} else {
    include 'Navbar.php'; // Include user navbar
}

// Rest of your HTML and PHP code for the dashboard page
?>

<!DOCTYPE html>
<html>

<head>
    <title> Dashboard </title>
    <link rel="stylesheet" href="Dashboard.css">
    <link rel="icon" type="image/x-icon" href="icon.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <style>
        .pagination {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
    </style>
</head>

<body style="background-color: #bcbcbc;">
    <br>
    <h1 style="text-align: center;">Dashboard</h1>

    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "STORE_MANAGEMENT_SYSTEM";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {
        $itemsPerPage = 7;
        $currentPage = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($currentPage - 1) * $itemsPerPage;

        // Sorting
        if (isset($_POST['sort'])) {
            $sort = $_POST['sort'];

            switch ($sort) {
                case 'Sayur':
                    $sortBy = 'Sayur';
                    break;
                case 'Barangan Kering':
                    $sortBy = 'Barangan Kering';
                    break;
                case 'Minuman':
                    $sortBy = 'Minuman';
                    break;
                case 'Tenusu':
                    $sortBy = 'Tenusu';
                    break;
                case 'isi rumah':
                    $sortBy = 'isi rumah';
                    break;
                case 'Makanan Ringan':
                    $sortBy = 'Makanan Ringan';
                    break;
                default:
                    $sortBy = 'Prodcut_ID'; // Default sorting criteria
                    break;
            }

            $queryview = "SELECT * FROM STOCK WHERE Type = '$sortBy'";


        }

        // Searching
        elseif (isset($_POST['search'])) {
            $search = $_POST['search'];
            $queryview = "SELECT * FROM STOCK WHERE Product_Name LIKE '%$search%' OR Type LIKE '%$search%' OR Expiry_Date LIKE '%$search%' OR Prodcut_ID LIKE '%$search%' OR NickName LIKE '%$search%'";
        }

        // Default query without sorting or searching
        else {
            $sortBy = 'Prodcut_ID'; // Default sorting criteria
            $queryview = "SELECT * FROM STOCK ORDER BY $sortBy LIMIT $itemsPerPage OFFSET $offset";
        }



        // Execute the query
        $resultQ = $conn->query($queryview);

        // Check for query execution success
        if (!$resultQ) {
            die("Query failed: " . $conn->error);
        }


        $resultQ = $conn->query($queryview);

        if (!$resultQ) {
            die("Query failed: " . $conn->error);
        }
    ?>

        <div class="container">
            <form method="post">
                <input type="text" name="search" placeholder="Search by any keywords" />
                <button type="submit">Search</button>
            </form>

            <form method="post" id="sortForm">
                <br>
                <label for="sort">Sort by type:</label>
                <select name="sort" id="sort">
                    <option value="default">Default</option>
                    <option value="Sayur">Sayur</option>
                    <option value="Barangan Kering">Barangan Kering</option>
                    <option value="Minuman">Minuman</option>
                    <option value="Tenusu">Tenusu</option>
                    <option value="isi rumah">Isi Rumah</option>
                    <option value="Makanan Ringan">Makanan Ringan</option>
                    <!-- Add more options for other sorting criteria if needed -->
                </select>
            </form>
    </div>
            <br>
            <?php 
            if (isset($_POST['sort'])) {
                if ($sortBy == 'Prodcut_ID') {
                echo "<h4 style='text-align: center; color:green;'>All Product</h4>";
            } else {
                echo "<h4 style='text-align: center; color:green;'>$sortBy</h4>";
             
            }
         } ?>

            <div class="container">
            <table border="2">
                <tr>
                    <th> Product ID </th>
                    <th> Image </th>
                    <th> Product Name </th>
                    <th> Price </th>
                    <th> Quantity </th>
                    <th>Expiry Date</th>
                    <th>Date Enter Store</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>NickName (Staff ID)</th>
                    <th>Edit</th>
                    <th>Change Status</th>
                    <th>Change Status</th>
                </tr>

                <?php
                function displayTableRow($row, $class)
                {
                ?>
                    <tr class="<?php echo $class; ?>">
                        <td><?php echo $row["Prodcut_ID"]; ?></td>
                        <td>
                            <?php
                            // Check if the profile picture path is set in the database
                            if (!empty($row["Stock_Pic"])) {
                            ?>
                                <img src="<?php echo $row["Stock_Pic"]; ?>" style="max-width: 100px; max-height: 100px;" width="100" height="100">
                            <?php
                            }
                            ?>
                        </td>

                        <td><?php echo $row["Product_Name"]; ?></td>
                        <td><?php echo 'RM ' . number_format($row["Price"], 2); ?></td>
                        <td><?php echo $row["Quantity"]; ?></td>
                        <td><?php echo $row["Expiry_Date"]; ?></td>
                        <td><?php echo $row["Date_In_Store"]; ?></td>
                        <td><?php echo $row["Type"]; ?></td>
                        <td><?php echo $row["Description"]; ?></td>
                        <td><?php echo $row["Status"]; ?></td>
                        <td>
                            <?php echo $row["NickName"]; ?> (<?php echo $row["Staff_ID"]; ?>)
                        </td>
                        <td><button class="edit-button" onclick="location.href='Stock_Edit_Details.php?ProductID=<?php echo $row["Prodcut_ID"]; ?>'">Edit</button></td>
                        <td><a href="Stock_Available.php?ProductID=<?php echo $row["Prodcut_ID"]; ?>" class="available-btn">Available</a></td>
                        <td><a href="Stock_Unavailable.php?ProductID=<?php echo $row["Prodcut_ID"]; ?>" class="unavailable-btn">Unavailable</a></td>

                    </tr>

                <?php
                }

                $lowQuantityRows = array();
                $normalQuantityRows = array();

                if ($resultQ->num_rows > 0) {
                    while ($row = $resultQ->fetch_assoc()) {
                        $quantityClass = ($row["Quantity"] < 15) ? 'low-quantity' : '';

                        if ($row["Quantity"] < 15) {
                            $lowQuantityRows[] = $row;
                        } else {
                            $normalQuantityRows[] = $row;
                        }
                    }

                    foreach ($lowQuantityRows as $row) {
                        displayTableRow($row, 'low-quantity');
                    }

                    foreach ($normalQuantityRows as $row) {
                        displayTableRow($row, '');
                    }

                    // Pagination
                    $totalItemsQuery = "SELECT COUNT(*) as total FROM STOCK";
                    $totalItemsResult = $conn->query($totalItemsQuery);
                    $totalItems = $totalItemsResult->fetch_assoc()['total'];
                    $totalPages = ceil($totalItems / $itemsPerPage);

                ?>
            </table>
            <div class="pagination">
                <?php if ($currentPage > 1) : ?>
                    <a href="?page=<?php echo $currentPage - 1; ?>">&lt; Prev</a>
                <?php endif; ?>
                <span>Page <?php echo $currentPage; ?> of <?php echo $totalPages; ?></span>
                <?php if ($currentPage < $totalPages) : ?>
                    <a href="?page=<?php echo $currentPage + 1; ?>">Next &gt;</a>
                <?php endif; ?>
            </div>

            <br><br>
    <?php
                } else {
                    echo "<tr><td style='color:red;' colspan='8'> You didn't have any product in Store </td></tr>";
                }

                $conn->close();
            }
    ?>
        </div>

        <script>
            document.getElementById('sort').addEventListener('change', function() {
                document.getElementById('sortForm').submit();
            });
        </script>

</body>

</html>