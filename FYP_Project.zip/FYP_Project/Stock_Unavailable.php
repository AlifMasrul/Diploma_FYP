<?php
session_start();

if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Update Stock</title>
    <?php
    $ProductId = $_REQUEST["ProductID"];
    ?>
    <link rel="icon" type="image/x-icon" href="icon.png">
</head>
<center>

    <body>
        <br><br>
        <h2> Update Stock Status </h2>

        <?php

        $host = "localhost";
        $user = "root";
        $pass = "";
        $db = "STORE_MANAGEMENT_SYSTEM";

        $conn = new mysqli($host, $user, $pass, $db);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } else {
            $queryUpdate = "UPDATE  STOCK SET Status = 'Unavailable', Quantity = 0 WHERE Prodcut_ID = '" . $ProductId . "' ";

            if ($conn->query($queryUpdate) === TRUE) {
                echo "<p style='color:green;'>  Status has been changed from database !</p>";
            } else {
                echo "<p style='color:red;'>Query problems! : " . $conn->error . "</p>";
            }
        }
        $conn->close();
        ?>

    </body>
</center>

</html>