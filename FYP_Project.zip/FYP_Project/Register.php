<?php
session_start();

if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Register Profile</title>
    <link rel="stylesheet" href="Register.css">
</head>

<body style="background-color: #bcbcbc;">
    <header>
        <br><br>

        <link rel="icon" type="image/x-icon" href="icon.png">
    </header>
    <main>
        <h1>Staff Registration</h1>
        <br><br>
        <form name="Register" action="RegVerify.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name <span class="required">*</span></label>
                <input type="text" id="name" name="Nama" size="60" maxlength="55" required>
            </div>
            <div class="form-group">
                <label for="Nickname">NickName <span class="required">*</span></label>
                <input type="text" id="Nickname" name="Nickname" size="60" maxlength="55" required>
            </div>
            <div class="form-group">
                <label for="dob">Date Of Birth <span class="required">*</span></label>
                <input type="date" id="dob" name="Dob" size="15" maxlength="10" max="2005-01-01" required>
            </div>
            <div class="form-group">
                <label for="password">Password <span class="required">*</span></label>
                <input type="password" id="password" name="UserPass" size="20" maxlength="15" required>
            </div>
            <div class="form-group">
                <label for="profile-pic">Profile Picture<span class="required">*</span></label>
                <input type="file" name="profile_pic" id="profile-pic" required>
            </div>
            <div class="form-buttons">
                <button type="submit">Submit</button>
                <button type="reset">Cancel</button>
            </div>

        </form>
        <br><br>
    </main>
</body>

</html>