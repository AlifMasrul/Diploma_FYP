<?php
session_start(); // Start the session at the beginning of your script


if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title> Stock Edit Details</title>
    <link rel="stylesheet" href="Stock_Edit_Details.css">
    <link rel="icon" type="image/x-icon" href="icon.png">
</head>

<body style="background-color: #bcbcbc;">

    <center>
        <br><br>
        <h2> Update Stock details: </h2>
        <form name="UpdateForm" action="Stock_Edit_Save.php" method="POST">

            <?php
            $ProductId = $_REQUEST["ProductID"];
            $host = "localhost";
            $user = "root";
            $pass = "";
            $db = "STORE_MANAGEMENT_SYSTEM";

            $conn = new mysqli($host, $user, $pass, $db);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            } else {
                $queryGet = "SELECT * FROM STOCK WHERE Prodcut_ID = '" . $ProductId . "' ";
                $resultGet = $conn->query($queryGet);

                if ($resultGet->num_rows > 0) {
                    while ($row = $resultGet->fetch_assoc()) {
            ?>

                        <table>
                            <tr>
                                <td>Product Id:</td>
                                <td><b><?php echo $row["Prodcut_ID"]; ?></b></td>
                            </tr>
                            <tr>
                                <td>Image:</td>
                                <td class="image">
                                    <?php
                                    // Check if the profile picture path is set in the database
                                    if (!empty($row["Stock_Pic"])) {
                                    ?>
                                        <img src="<?php echo $row["Stock_Pic"]; ?>" style="max-width: 100px; max-height: 100px;" width="100" height="100">
                                    <?php
                                    }
                                    ?>
                                    <br><br>
                                    Click<a href="Stock_Image_Edit.php?ProductID=<?php echo $row["Prodcut_ID"]; ?>" class="available-btn"> here </a>to edit stock picture
                                </td>
                            </tr>
                            <br>
                            <tr>
                                <td>Product Name:</td>
                                <td><input type="text" class="Product" name="product_name" size="20" value="<?php echo $row["Product_Name"]; ?>" maxlength="30" required></td>
                            </tr>
                            <tr>
                                <td>Price:</td>
                                <td><input type="number" name="price" size="20" min="0.2" step="0.1" value="<?php echo number_format($row["Price"], 2); ?>" maxlength="30" required></td>
                            </tr>
                            <tr>
                                <td>Quantity:</td>
                                <td><input type="number" name="quantity" step="1.0" min="1" value="<?php echo $row["Quantity"]; ?>" required></td>
                            </tr>
                            <tr>
                                <td>Expiry Date:</td>
                                <td><input type="date" name="ExpiryDate" value="<?php echo $row["Expiry_Date"]; ?>" required style="width: 200px; height: 30px;"></td>
                            </tr>
                            <tr>
                                <td>Date that enter store:</td>
                                <td><input type="date" name="Date_Enter_Store" value="<?php echo $row["Date_In_Store"]; ?>" required style="width: 200px; height: 30px;"></td>
                            </tr>
                            <tr>
                                <td>Type:</td>
                                <td>
                                    <select name="type">
                                        <option value="Sayur" <?php if ($row["Type"] == 'Sayur') echo 'selected'; ?>>Sayur</option>
                                        <option value="Barangan Kering" <?php if ($row["Type"] == 'Barangan Kering') echo 'selected'; ?>>Barangan Kering</option>
                                        <option value="Minuman" <?php if ($row["Type"] == 'Minuman') echo 'selected'; ?>>Minuman</option>
                                        <option value="Tenusu" <?php if ($row["Type"] == 'Tenusu') echo 'selected'; ?>>Produk Tenusu</option>
                                        <option value="isi rumah" <?php if ($row["Type"] == 'isi rumah') echo 'selected'; ?>>Barangan Isi Rumah</option>
                                        <option value="Makanan Ringan" <?php if ($row["Type"] == 'Makanan Ringan') echo 'selected'; ?>>Makanan Ringan</option>
                                        <!-- Add more options as needed -->
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Description:</td>
                                <td><input type="text" class="desc" name="desc" value="<?php echo $row["Description"]; ?>"></td>
                            </tr>

                        </table>
                        <input type="hidden" name="ProductId" value="<?php echo $row["Prodcut_ID"]; ?>">
                        <input type="submit" value="Update Details">
                        <input type="Reset" value="Reset">

            <?php
                    }
                } else {
                    echo "<p colspan='8' style='color:red;'>No data selected</p>";
                }
                $conn->close();
            }
            ?>

        </form>
    </center>
</body>

</html>