<?php
session_start();

$_SESSION['login_date'] = date('Y-m-d');

if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database configuration
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "STORE_MANAGEMENT_SYSTEM";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Connection failed" . $conn->connect_error);
    }

    $ProductName = $_POST["product_name"] ?? "";
    $Price = $_POST["price"] ?? "";
    $Quantity = $_POST["quantity"] ?? "";
    $ExpiryDate = $_POST["expiry_date"] ?? "";
    $DateInStore = $_POST["date_in_store"] ?? "";
    $ItemType = $_POST["item_type"] ?? "";
    $Desc = $_POST["desc"] ?? "";
    $StockPic = $_FILES["stock_pic"] ?? [];

    if (empty($ProductName) || empty($Price) || empty($Quantity) || empty($ExpiryDate) || empty($DateInStore) || empty($ItemType)) {
        echo "<p style='color:red;'>One or more required fields are missing</p>";
        exit;
    }

    $targetDirectory = "stock_pics/";
    $targetFile = $targetDirectory . basename($StockPic["name"]);

    if (!is_dir($targetDirectory) || !is_writable($targetDirectory)) {
        echo "<p style='color:red;'>Target directory is not valid</p>";
        exit;
    }

    if (!move_uploaded_file($StockPic["tmp_name"], $targetFile)) {
        echo "<p style='color:red;'>Failed to move the uploaded file</p>";
        exit;
    }

    $nickname = isset($_SESSION["NickName"]) ? $_SESSION["NickName"] : "";

    $queryInsert = $conn->prepare("INSERT INTO STOCK(Product_Name, Price, Quantity, Expiry_Date, Date_In_Store, Type, Description, Staff_ID, NickName, Status, Stock_Pic)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Available', ?)");

    if ($queryInsert) {
        $queryInsert->bind_param("sdisssssss", $ProductName, $Price, $Quantity, $ExpiryDate, $DateInStore, $ItemType, $Desc, $_SESSION["Staff_ID"], $nickname, $targetFile);

        if ($queryInsert->execute()) {
            echo "<p style='color:green;'>Success insert record</p>";
        } else {
            echo "<p style='color:red;'>Connection error" . $conn->error . "</p>";
        }

        $queryInsert->close();
    } else {
        echo "<p style='color:red;'>Prepare failed: " . $conn->error . "</p>";
    }

    $conn->close();
}
