<?php
session_start(); // Start the session at the beginning of your script


if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title> Stock Delete</title>
    <link rel="stylesheet" href="Stock_Delete_View.css">
    <link rel="icon" type="image/x-icon" href="icon.png">
</head>

<body>
    <br><br>
    <h2> STOCK DELETE </h2>

    <center>
        <form action="Stock_Delete_Chosen.php" method="POST" onsubmit="return confirm('Are you sure to delete this record?')">
            <table>
                <tr>
                    <th> Choose </th>
                    <th> Image </th>
                    <th> Product ID </th>
                    <th> Product Name </th>
                    <th> Price </th>
                    <th> Quantity </th>
                    <th>Expiry Date</th>
                    <th>Date Enter Store</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Status</th>

                </tr>

                <?php
                $host = "localhost";
                $user = "root";
                $pass = "";
                $db = "STORE_MANAGEMENT_SYSTEM";

                $conn = new mysqli($host, $user, $pass, $db);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                } else {
                    $queryview = "SELECT * FROM STOCK ORDER BY Product_Name ASC ";
                    $resultQ = $conn->query($queryview);
                ?>

                    <?php
                    if ($resultQ->num_rows > 0) {
                        while ($row = $resultQ->fetch_assoc()) {
                    ?>
                            <tr>
                                <td> <input type="checkbox" name="ProductID[]" value="<?php echo $row["Prodcut_ID"]; ?>"> </td>
                                <td> <img src="<?php echo $row["Image"]; ?>" width="100" length="100"> </td>
                                <td> <?php echo $row["Prodcut_ID"]; ?> </td>
                                <td> <?php echo $row["Product_Name"]; ?> </td>
                                <td> <?php echo $row["Price"]; ?> </td>
                                <td> <?php echo $row["Quantity"]; ?> </td>
                                <td> <?php echo $row["Expiry_Date"]; ?> </td>
                                <td> <?php echo $row["Date_In_Store"]; ?> </td>
                                <td> <?php echo $row["Type"]; ?> </td>
                                <td> <?php echo $row["Description"]; ?> </td>
                                <td> <?php echo $row["Status"] ?></td>

                            </tr>
                <?php
                        }
                    } else {
                        echo "<tr><td colspan='8'> NO data selected </td></tr>";
                    }
                }
                $conn->close();
                ?>

            </table>
            <br>
            <button type="submit" name="status" value="available">Available</button>
            <button type="submit" name="status" value="unavailable">Unavailable</button>
            <br><br>
        </form>
    </center>
</body>

</html>