<?php
// Start the session at the beginning of your script
session_start();

$StaffID = $_POST['StaffId'];
$UserPass = $_POST['UserPass'];

$host = "localhost";
$username = "root";
$password = "";
$dbname = "STORE_MANAGEMENT_SYSTEM";

$link = mysqli_connect($host, $username, $password, $dbname);

if ($link->connect_error) {
    die("Connection failed: " . $link->connect_error);
} else {
    $queryCheck = "SELECT * FROM USER WHERE Staff_ID = '$StaffID' AND Status != 'Block'";
    $resultCheck = $link->query($queryCheck);

    if ($resultCheck->num_rows == 0) {
        echo "<br><p style='color:red'>Staff ID does not exist or your account has been blocked</p><br>";
        echo "<p style='color:#84A4FC'>Click <a style='color:#84A4FC' href='Login_Page.html'>here</a> to go to the login page </p>";
        echo "<p style='color:#84A4FC'>Click <a style='color:#84A4FC' href='Register.html'>here</a> to go to the Register page </p>";
    } else {
        $row = $resultCheck->fetch_assoc();
        if ($row["Password"] == $UserPass) {
            $_SESSION["Staff_ID"] = $StaffID;
            $_SESSION["NickName"] = $row["NickName"];
            $_SESSION["User_Type"] = $row["User_Type"];
            header("Location: Dashboard.php");
            exit; // Make sure to exit after a header redirect
        } else {
            echo "<br><p style='color: red'>Wrong password!!! </p><br>";
            echo "<p style='color:#84A4FC'>Redirecting to <a style='color:#84A4FC' href='Login_Page.html'>login page</a></p>";
            echo "<script>setTimeout(function() { window.location.href = 'Login_Page.html'; }, 3000);</script>";
            exit; // Make sure to exit after displaying the error message
        }
    }
}

mysqli_close($link);
?>
