<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .error-message {
            color: red;
            margin-bottom: 10px;
        }

        .link {
            color: #84A4FC;
        }
    </style>
</head>
<body style="background-color: #bcbcbc;">
    <div class="container">
        <?php
        // Start the session at the beginning of your script
        session_start();

        $StaffID = $_POST['StaffId'];
        $UserPass = $_POST['UserPass'];

        $host = "localhost";
        $username = "root";
        $password = "";
        $dbname = "STORE_MANAGEMENT_SYSTEM";

        $link = mysqli_connect($host, $username, $password, $dbname);

        if ($link->connect_error) {
            die("Connection failed: " . $link->connect_error);
        } else {
            $queryCheck = "SELECT * FROM USER WHERE Staff_ID = '$StaffID' AND Status != 'Block'";
            $resultCheck = $link->query($queryCheck);

            if ($resultCheck->num_rows == 0) {
                echo "<p class='error-message'>Staff ID does not exist or your account has been blocked</p>";
                echo "<p style='text-align:center;'>Click <a class='link' href='Login_Page.html'>here</a> to go to the login page </p>";
            } else {
                $row = $resultCheck->fetch_assoc();
                if ($row["Password"] == $UserPass) {
                    $_SESSION["Staff_ID"] = $StaffID;
                    $_SESSION["NickName"] = $row["NickName"];
                    $_SESSION["User_Type"] = $row["User_Type"];
                    header("Location: Dashboard.php");
                    exit; // Make sure to exit after a header redirect
                } else {
                    echo "<p class='error-message'>Wrong password!!!</p>";
                    echo "<p>Redirecting to Login Page <br> or <br> Click <a class='link' href='Login_Page.html'>here</a> to go Login Page</p>";
                    echo "<script>setTimeout(function() { window.location.href = 'Login_Page.html'; }, 3000);</script>";
                    exit; // Make sure to exit after displaying the error message
                }
            }
        }

        mysqli_close($link);
        ?>
    </div>
</body>
</html>
