<?php
session_start(); // Start the session at the beginning of your script

$_SESSION['login_date'] = date('Y-m-d');

if (isset($_SESSION['Staff_ID'])) {
    // User is logged in
    if ($_SESSION['User_Type'] == 'Admin') {
        include 'Admin_Navbar.php'; // Include admin navbar
    } else {
        include 'Navbar.php'; // Include user navbar
    }
} else {
    // Session does not exist or user is not logged in
    // You can redirect to the login page or display an error message
    header("Location: Login_Page.html");
    exit;
}
?>

<!DOCTYPE html>
<html>
    <?php
    $UserName = $_POST ["Nama"];
    $UserDOB = $_POST["Dob"];
    $UserPwd = $_POST ["UserPass"];
    $Nickname = $_POST["Nickname"];
       ?>
<head>
        <title> Store Management System </title>
        <link rel="icon" type="image/x-icon" href="icon.png">
        <link rel="stylesheet" href="RegVerify.css">

</head>
<body>
    <h1> You have succesful register your account! </h1>


    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "STORE_MANAGEMENT_SYSTEM";

    $conn = new mysqli ($host, $user, $pass, $db);

    if ($conn->connect_error){
        die("Connection failed" . $conn->connect_error);
    }
    else{

            // File upload handling
        $targetDirectory = "profile_pics/"; // Specify the directory where you want to store the uploaded profile pictures
        $targetFile = $targetDirectory . basename($_FILES["profile_pic"]["name"]);

    if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $targetFile)) {
        // File uploaded successfully
    } else {
        // Error uploading file
        echo "Sorry, there was an error uploading your profile picture.";
    }
         // Update the database insertion query to include the file information
        $querryInsert = "INSERT INTO USER (Name, Dob, Password, NickName, User_Type, Status, Profile_Pic)
                        VALUES ('".$UserName."','".$UserDOB."','".$UserPwd."', '".$Nickname."', 'user', 'Active', '".$targetFile."')";

        if ($conn->query($querryInsert) === TRUE) {
            echo "<center><p style='color:green;'>You have successfully register a user</p></center>";
        }
        else{
            echo "<p style='color:red;'> Connection error ".$conn->error. "</p>";
        }

    }
    $conn->close();
    ?>
    
</body>
</html>